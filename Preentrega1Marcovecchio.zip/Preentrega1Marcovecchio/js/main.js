const metodoPago = prompt("Ingrese el metodo de pago para Acceder A Los Juegos");

if (metodoPago == "") {
    alert("Aun no pagaste");
}
else {
    alert("Nombre de metodo de pago ingresado");
}


switch(metodoPago.toLowerCase()){
    case 'efectivo':
        console.log('Pagaste con ' + metodoPago);
        break;
    case 'cheque': 
        console.log('Pagaste con ' + metodoPago);
        break;
    case 'tarjeta':
        console.log('Pagaste con ' + metodoPago);
        break;
    case 'bitcoin':
        console.log('Pagaste con ' + metodoPago);
        break;
    default:
        console.log("Aun no pagaste");

}


   
    let imagenes=new Array(
        ['assets/1.jpg','1.jpg'],
        ['assets/2.jpg','2.jpg'],
        ['assets/3.jpg','3.jpg'],
        ['assets/4.jpg','4.jpg']
    );
    let contador=0;



    function rotarImagenes()
    {

        contador++
        document.getElementById("imagen").src=imagenes[contador%imagenes.length][0];
        document.getElementById("link").href=imagenes[contador%imagenes.length][1];
    }

    onload=function()
    {

        rotarImagenes();
 

        setInterval(rotarImagenes,5000);
    }
